package com.example.demo;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class Week1203JpAjspApplication {

	public static void main(String[] args) {
		SpringApplication.run(Week1203JpAjspApplication.class, args);
	}

}
