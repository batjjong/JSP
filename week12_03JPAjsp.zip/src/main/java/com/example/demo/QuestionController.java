package com.example.demo;

import java.time.LocalDateTime;
import java.util.List;

import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.ResponseBody;

import com.example.demo.dao.QuestionRepository;
import com.example.demo.entity.Question;

@Controller
public class QuestionController {
	private QuestionRepository questionRepository;
	public QuestionController(QuestionRepository questionRepository) {
		this.questionRepository = questionRepository;
	}
	
	@GetMapping("/")
	public String index() {
		return "index";
	}
	
	@GetMapping("/insertform")
	public String insertform() {
		return "insertform";
	}
	
	@GetMapping("/insertResult")
	public String insertResult(Question question) {
		question.setCreateDate(LocalDateTime.now());
		questionRepository.save(question);
		
		//컨트롤러에서 바로 요청 보내는 방법
		return "redirect:/list";
	}
		
	@GetMapping("/list")
	public String list(Model model) {
		List<Question> questionList = questionRepository.findAll();
		model.addAttribute("questionList",questionList);
		return "question_list";
	}
	
	@GetMapping("/insert")
	public void insert() {
		//1개의 레코드 = Question 객체 모양
		Question question = new Question();
		question.setSubject("JPA가 무엇인가요?:");
		question.setContent("스프링부트에서 DB 사용하는 방법");
		question.setCreateDate(LocalDateTime.now());
		
		//테이블에 데이터 넣기
		questionRepository.save(question);
		
		
		Question question2 = new Question();
		question2.setSubject("JPA가 무엇인가요?:");
		question2.setContent("스프링부트에서 DB 사용하는 방법");
		question2.setCreateDate(LocalDateTime.now());
		
		//테이블에 데이터 넣기
		questionRepository.save(question2);
		
	}
	
	@GetMapping("/display")
	@ResponseBody
	public List<Question> display() {
		List<Question> list = questionRepository.findAll();
		return list;
	}
	
}
